// *** Structures and Classes ***

// ** Instances **

// * Stored properties and referencing *
//class Cl1 {
//    var p1: Int
////    var p2: Int
//    let p2: Int
//    
//    init(p1: Int, p2: Int) {
//        self.p1 = p1
//        self.p2 = p2
//    }
//}
//
//var inst1 = Cl1(p1: 1, p2: 2)
//var inst2 = Cl1(p1: 3, p2: 4)
//inst2 = inst1
//print(inst2.p2)


// * Lazy properites *

//class Cl2 {
////    var p1 = fetchData()
//    lazy var p1 = fetchData()
//    func fetchData() -> Int {
//        var temp = 0
//        for i in 1...5 {
//            temp+=i
//        }
//        return temp
//    }
//    
//    
//    var p2: Int {
//        lazy var temp = 1
//        for i in 1...20 {
//            temp *= i
//        }
//        return temp
//    }
//}
//
//var inst3 = Cl2()
//print(inst3.p1)
//print(inst3.p2)


// * Computed *

//class Cl3 {
//    var p1: Int
//    var p2: Int = 1
//    var p3: Int {
//        get{
//            p1 * p1
//        }
//        set(newVal){
//            p2 = newVal * 5
//        }
//    }
//    
//    init(p1: Int){
//        self.p1 = p1
//    }
//}

//var inst1 = Cl3(p1: 5)
//print("p1: ",inst1.p1)
//// Getter calculates and return value of computed property
//print("p3: ",inst1.p3)
//// Getter doesn't call setter, so p2 is unchanged
//print("p2: ",inst1.p2)
//
//print()
//
//// Setter is called, and it updates the value of p2
//inst1.p3 = 100
//print("p1: ",inst1.p1)
//print("p3: ",inst1.p3)
//print("p2: ",inst1.p2)


// * Type properties *

//struct St1 {
//    static var v2: Int = 0
//    
//    func inc(){
//        St1.v2 += 1
//    }
//}
//
//var inst1 = St1()
//print(St1.v2)
//inst1.inc()
//print(St1.v2)


// ** Methods **


//struct St1 {
//    var v1: Int = 0
//    mutating func f1(inc: Int){
//        v1 += inc
//    }
//}
//
//var inst1 = St1()
//inst1.f1(inc: 2)
//print(inst1.v1)


//struct St2 {
//    var v1: Int
//    var v2: Int
//    
//    mutating func f2(inst: St2){
//        self = inst
//    }
//}
//
//var inst2 = St2(v1: 5, v2: 5)
//var inst3 = St2(v1: 7, v2: 7)
//print("Before mutating: ",inst2.v1, inst2.v2)
//inst2.f2(inst: inst3)
//print("After mutating: ",inst2.v1, inst2.v2)


// * Type methods *


//struct St3 {
//    static var v1: Int = 0
//    var v2: Int
//    
//    static func f3(inc: Int){
//        v1 += inc
//    }
//    
////    static func f3(inc: Int){
////        v2 += inc
////    }
//    
//}
//
//St3.f3(inc: 10)
//print(St3.v1)
//St3.v1 += 100
//print(St3.v1)
//
//
//class St4 {
//    static var v1: Int = 0
//    var v2: Int = 0
//    
//    class func f3(inc: Int){
//        v1 += inc
//    }
//    
////    static func f3(inc: Int){
////        v2 += inc
////    }
//    
//}
//
//St4.f3(inc: 10)
//print(St4.v1)
//St4.v1 += 100
//print(St4.v1)



// ** Inheritance **

//class parent {
//    var p1: Int
//    init(p1: Int){
//        self.p1 = p1
//    }
//    func f1 () {
//        print("This belongs to parent")
//    }
//}
//
//class child : parent {
//    var p2: Int = 0
//}
//
//var inst1 = parent(p1: 20)
//var inst2 = child(p1: 10)
//
//print(inst1.p1)
//print(inst2.p1)
//inst2.f1()


// Type stored
//class parent {
//    static var v1: Int = 5
//}
//
//class child: parent { }
//
//var inst1 = child()
//print(inst1.v1)


// Override
//class Parent {
//    var v1: Int = 5
////    func f1() {
////        print("Parent fucntion")
////    }
//    final func f1() {
//        print("Parent fucntion")
//    }
//}
//
//class Child: Parent {
//    override func f1() {
//        print("Child function")
//    }
//}
//
//var inst1 = Parent()
//inst1.f1()
//var inst2 = Child()
//inst2.f1()


// ** Initailizers **

// * Optional initialzers *

struct St1 {
    var v1: Int
    var v2: Int?
    
    init(v1: Int){
        self.v1 = v1
    }
}

//var inst1 = St1(v1: 5)
//print(inst1.v1)
//print(inst1.v2)
//inst1.v2 = 10
//print(inst1.v2)
//if let num = inst1.v2 {
//    print("Variable is not nil")
//    print(num)
//} else {
//    print("Variable is nil")
//}


// * Convenience Initializers *

//class Circle {
//    var radius: Double
//    
//    init(radius: Double){
//        self.radius = radius
//    }
//    
//    convenience init(dia: Double){
//        self.radius = dia / 2
//    }
//}

























