// *** Extensions ***


// ** Computed properties **

//extension Double {
//    var mm: Double { self * 0.001 }
//    var cm: Double { self * 0.01 }
//    var km: Double { self * 1000 }
//}
//
//print(25.6.km, "meters")
//print(25.6.cm, "meters")
//print(25.6.mm, "meters")
//
//var dist: Double = 150
//var result = dist.mm
//print(result, "meters")



// ** Initializers **

//struct Point {
//    var x: Double
//    var y: Double
//}
//
//extension Point {
//    init(value: Double) {
//        x = value
//        y = value
//    }
//    
//    init(value: String){
//        x = Double(value) ?? 0
//        y = Double(value) ?? 0
//    }
//}
//
//var inst1 = Point(x: 12, y: 42)
//var inst2 = Point(value: 20.45)
//var inst3 = Point(value: "23.45")
//
//print(inst1)
//print(inst2)
//print(inst3)


// * Convenience Initializers *

//class Point {
//    var x: Int
//    var y: Int
//    
//    init(x:Int, y:Int){
//        self.x = x
//        self.y = y
//    }
//}
//
//extension Point {
//    convenience init (value: String){
//        self.init(x: (Int(value) ?? 0) , y: (Int(value) ?? 0))
//    }
//}
//
//var inst4 = Point(x: 12, y: 42)
//print(inst4.x, inst4.y)
//
//var inst5 = Point(value: "20")
//print(inst5.x, inst5.y)
//
//var inst6 = Point(value: "20.45")
//print(inst6.x, inst6.y)



// ** Methods **

//struct Point {
//    var x: Double
//    var y: Double
//    
//    func printPoint(){
//        print(x,y)
//    }
//}
//
//extension Point {
//    var computedProp: Double {
//        x + y
//    }
//    mutating func setCords(coords: (Double,Double)) -> (Double, Double, Double){
//        x = coords.0
//        y = coords.1
//        return (x,y,computedProp)
//    }
//}
//
//var point1 = Point(x: 12, y: 42)
//point1.printPoint()
//print(point1.setCords(coords: (12.342, 42.621)))

// Note: Type methods can be defined in extensions of both classes as well as structs.



// ** Subscripts **

//class Subscript {
//    var arr: [Int]
//    
//    init(arr: [Int]){
//        self.arr = arr
//    }
//}
//
//extension Subscript {
//    subscript(index: Int) -> Int? {
//        guard ( index >= 0 && index < arr.count ) else {
//            return nil
//        }
//        return arr[index]
//    }
//}
//
//
//var inst1 = Subscript(arr: [1,2,3,4,5])
//print(inst1[3] ?? "Invalid index")
//print(inst1[10] ?? "Invalid index")


// ** Enums **

//enum Days: Int {
//    case mon, tue, wed, thurs, fri, sat, sun
//}
//
//extension Days {
//    func isWeekend() -> Bool {
//        switch self {
//        case .sat, .sun:
//            return true
//        default:
//            return false
//        }
//    }
//    
//    mutating func changeDay(){
//        switch self {
//        case .mon:
//            self = .sun
//        case .tue:
//            self = .sun
//        case .wed:
//            self = .sun
//        case .thurs :
//            self = .sun
//        case .fri:
//            self = .sun
//        case .sat:
//            self = .sun
//        case .sun:
//            self = .mon
//        }
//    }
//}
//
//var inst = Days.mon
//print(inst.isWeekend())
//var inst2 = Days.sat
//print(inst2.isWeekend())
//inst2.changeDay()
//print(inst2)


// ** Nested types **

//struct XYZ {
//    class ABC {
//        var x = 5
//    }
//}

//class XYZ {
//    struct ABC {
//        var x = 5
//    }
//}

//var inst1 = XYZ()
////var inst2 = inst1.ABC()
//var inst2 = XYZ.ABC()
//print(inst2.x)

// * Without extension *

//struct St1 {
//    var x: String
//    
//    enum Val {
//        case one(String)
//        case two(String)
//        case three(String)
//        
//        func check(){
//            switch self {
//            case .one(let val), .two(let val), .three(let val):
//                print("Value from enum:", val)
//            }
//        }
//    }
//}
//
//St1.Val.one("two").check()


// * With extension *

//struct St1 {
//    var x: String
//}
//
//extension St1 {
//    enum Val {
//        case one(String)
//        case two(String)
//        case three(String)
//        
//        func check(){
//            switch self {
//            case .one(let val), .two(let val), .three(let val):
//                print("Value from enum:", val)
//            }
//        }
//    }
//}
//
//St1.Val.one("two").check()



// *** Protocols ***


// ** Property and Method requirements **

//protocol Proto {
//    var v1: Int { get }
//    var v2: Int { get }
//    func f1() -> Bool
//}
//
//class Parent {
//    
//}
//
//class Child: Parent, Proto {
//    var v2: Int = 9
//    var v1: Int = 3
//    
//    func f1() -> Bool {
//        v2 += 5
//        return false
//    }
//}

// Child is class that conforms to the protocol Proto, and therefore must have implementation for the properties and methods declared in the protocol.

//protocol Toggleable {
//    mutating func toggle()
//}
//
//enum Switch : Toggleable {
//    case on, off
//    mutating func toggle(){
//        switch self {
//        case .on:
//            self = .off
//        case .off:
//            self = .on
//        }
//    }
//}
//
//var inst1 = Switch.on
//print(inst1)
//inst1.toggle()
//print(inst1)



// ** Initializer requirements **

//protocol Proto {
//    var v1: Int { get }
//    init(x: Int)
//}
//
//class Parent : Proto {
//    var v1: Int
//    
//    required init(x: Int) {
//        v1 = x
//    }
//    
////    init(x: Int) {
////        v1 = x
////    }
//}
//
//class Child: Parent {
//    
//}
//
//var inst1 = Child(x: 50)
//print(inst1.v1)



// ** Adding conformance through extension **

//protocol Proto {
//    var protoProp: Int { get }
//}
//
//extension Cl1: Proto {
//    var protoProp: Int {
//        return x + y
//    }
//}
//
//class Cl1 {
//    var x: Int
//    var y: Int
//    
//    init(x: Int, y: Int){
//        self.x = x
//        self.y = y
//    }
//}
//
//var inst1 = Cl1(x: 10, y: 12)
//print(inst1.protoProp)



// *** Generics ***

//func swapValues<T>(_ a: inout T, _ b: inout T){
//    var temp = a
//    a = b
//    b = temp
//}
//
//var v1 = 5
////var v2 = 10.76
//var v2 = 10
//
//swapValues(&v1, &v2)
//print(v1)
//print(v2)


//func printLine<T,U>(num a: T, str b: U){
//    print(a,b)
//}
//
//printLine(num:10, str:"TintBox")


// ** Associated Types **

//protocol Proto {
//    associatedtype Element
//    var val: Element { get }
//    func returnElement() -> Element
//}
//
//struct St1: Proto {
//    var val: Int
//    func returnElement() -> Int {
//        return val
//    }
//}
//
//var inst1 = St1(val: 57)
//var ele = inst1.returnElement()
//print(ele)


