
// *** String Interpolation and Concatenation Difference ***

//var s2: String? = "def"
//var s4 = "abc"
//var s1 = "\(s4) \(s2!)"
//var s3 = s4 + " " + s2!
//print(s3)
//print(s1)


//var s1 = "abc"
//var s2 = "def"
//var s3 = "ghi"
//
//print("\(s2)\(s2)\(s3)")
//// Single Operation
//
//print(s1 + s2 + s3)
//// Multiple Operations (2)


// ** guard **

//var arr: [Int] = []
//
//for i in 1...10 {
//    guard i%2 == 0 else{
//        continue
//    }
//    arr.append(i)

//}
//print(arr)


// *** if-let and guard-let (Optional binding) ***

//var xyz: Int?
//if let abc = xyz {
//    print("Not nil")
//} else{
//    print("nil")
//}


//var arr: [Int?] = [nil,1,2,nil,4,5]
//print(arr)
//
//for i in arr {
//    guard let abc = i else{
//        let index = arr.firstIndex(where: { $0 == nil })
//        arr.remove(at: index!)
//        continue
//    }
//}
//print(arr)


//var v1: String? = "abc"
//var v2: String?
//
//if let t1 = v1, let t2 = v2 {
//    print(t1)
//} else{
//    print("Either one or both are nil")
//}


// This won't work
//guard let v3 = v1 else {
//    print("nil")
//}
//
//print(v3)


//func guardLet (num: Int?){
//    guard let num else {
//        print("Parameter passed is nil")
//        return
//    }
//    print("Num obtained \(num)")
//}

// or

//func guardLet (num: Int?){
//    guard let num1 = num else {
//        print("Parameter passed is nil")
//        return
//    }
//    print("Num obtained \(num1)")
//}
//
//
//var num: Int?
////var num: Int? = 5
//guardLet(num: num)


//
//
//func ifLetEarlyExit (num: Int?){
//    if let n1 = num {
//        print("Parameter is \(n1)")
//    } else{
//        print("Parameter is nil")
//        return
//    }
//    print("Parameter can't be accessed here \(n1)")
//}


//ifLetEarlyExit(num: 5)



// *** Higher-order functions questions ***

// Q1. Basic operations
//var arr1 = [1,2,3,4,5]
//print(arr1.map{ $0 + 1 })
//print(arr1.reduce (0, { $0 + $1 }))
//print(arr1.filter { $0 > 4 })


// Q2. Given the array let numbers = [10, 15, 20, 25, 30], use a combination of map and filter to create a new array that contains double the value of numbers greater than 20


//let numbers = [10, 15, 20, 25, 30]
//
////let temp = numbers.filter { $0 > 20 }
////let ans = temp.map { $0 * 2 }
//
//let ans = numbers.filter{ $0 > 20 }.map{ $0 * 2}
//// Left to right associativity
//print(ans)


// Q3. compactMap

//let nums: [Int?] = [1,2,4,nil]
//print(nums.compactMap{ num in return num })

//let nums: [Int?] = [1,2,4,nil]
//print(nums.map{ num in
//    if let x = num {
//        print("\(x) is not nil")
//        return x
//    } else {
//        print("Nil found")
//        return 0
//    }
//})
    


// Q4. Write a Swift function using compactMap to convert the array ["1", "2", "three", "4"] into an array of integers.

//let arr4 = ["1", "2", "three", "4"]
//print(arr4.compactMap { Int($0) })


// Q5. Given the array let numbers = [3, 6, 9, 12, 15], write a single chained expression using filter, map, and reduce to: Filter out numbers divisible by 6, Multiply the remaining numbers by 2, Compute the sum of the resulting array.

//let numbers = [3, 6, 9, 12, 15]
//let ans = numbers.filter{ $0 % 6 == 0 }.map{ $0 * 2 }.reduce(0, { $0 + $1 })
//print(ans)


// Q6. Reduce the sum of an array to an array with two indices

//let numbers = [1,2,3,4,5,6]
//var ans = numbers.reduce( into: [0,0] ){ (result, num) in
//    result[0] += num
//    result[1] += num
//}
//
//print(ans)


// Q7. Given the array let numbers = [1, 2, 3, 4, 5, 6], use the reduce function to group the numbers into even and odd numbers in a dictionary

//let numbers = [1, 2, 3, 4, 5, 6]
//let ans = numbers.reduce( into: ["even": [], "odd": []] ){ (result, num) in
//    if(num % 2 == 0) {
//      result["even"]!.append(num)
//    } else {
//      result["odd"]!.append(num)
//    }
//}
//
////print(ans["Hello"])
//print(ans)
    
// Note: Dictionary lookup returns an optional. Methods cannot be applied on optional arrays without optional binding


// Q8. Exercise

//let nums = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"]
//let abcd: [String]? = ["1", "2", "3", "4", "5"]
//
//let rem = nums.reduce(into: ["0":[], "1":[], "2":[]])
//{ (result, str) in
//    var chr = Character(str)
//
//    var ascii = chr.asciiValue!
//    guard let ascii = chr.asciiValue else{
//        return
//    }
//    
////    var ascii = chr.asciiValue ?? 0
//    if( ascii % 3 == 0 ) { result["0", default:[]].append(str) }
//    else if( ascii % 3 == 1 ) { result["1", default:[]].append(str) }
//    else { result["2", default:[]].append(str) }
//    
////    if let ascii = chr.asciiValue {
////        if( ascii % 3 == 0 ) { result["0", default:[]].append(str) }
////        else if( ascii % 3 == 1 ) { result["1", default:[]].append(str) }
////        else { result["2", default:[]].append(str) }
////    } else {
////        
////    }
//    
//}
//
//print(rem)


//var dict1 = ["k1":23, "k2":(1,2,3,4)]
//var dict1: [String: Any] = ["k1":23, "k2":"abc"]
//print()


//func xyz(_ nums : Int...) -> Int {
//    abc(nums)
////    var temp = 0
////    for num in nums {
////        temp += num
////    }
////    return temp
//    let abc = Int...
//    return 0
//}
//
//func abc(_ aaaa : Int...) -> Int {
//    
//    
//}


//var a : Int? = 3
//var b = a
//print(a)
//
//print(xyz(1,2,3,4))

// Q9. Transform 2D array into 1D array

//let arr = [[1,2],[3,4],[5,6]]
//print(type(of: arr))
//
//let arr2 = arr.flatMap{ $0 }
//print(arr2)


// Q10. Calculate frequency

//let str = "abcdachslejlandnzkns"
//let ans = str.reduce(into: [:]){ result, chr in
//    result[chr, default:0] += 1
//}
//
//print(ans)


// Q11. Use higher-order functions to calculate the total sum of all prices.

//let items = [["price": 10], ["price": 20], ["price": 30]]
//
//let ans = items.reduce(0, { v1, v2 in
//        v1 + v2["price"]
//})
//
//// v1 -> accumulator variable
//// v2 -> Iterating variable
//
//print(ans)




