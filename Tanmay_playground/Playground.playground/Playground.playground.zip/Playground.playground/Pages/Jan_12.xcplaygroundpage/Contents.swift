
// *** Ordered dictionary ***

struct Dict {
    var arr: [String] = []
    var dict: [String: Int] = [:]
    var count = 0
    var isEmpty = true
    
    
    subscript(key: String) -> Int {
        get{
            if let val = dict[key] {
                return val
            }
            return 0
        }
        set(newValue){
            arr.append(key)
            dict[key] = newValue
            count = arr.count
            isEmpty = arr.isEmpty
        }
    }
    
    
    func printDict(){
        var temp: [[String:Int]] = []
        for i in arr {
            temp.append([i:dict[i]!])
        }
        print(temp)
    }
    
    
    mutating func updateValue(_ val: Int, forKey key: String){
        if let entry = dict[key] {
            dict[key] = val
            print("Value of \(key) updated to \(val) \n")
            return
        }
        arr.append(key)
        dict[key] = val
    }
    
    
    mutating func deleteValue(forKey key: String){
        guard let entry = dict[key] else {
            print("Key not found\n")
            return
        }
        var index = arr.firstIndex(of: key)
        arr.remove(at: index!)
        dict.removeValue(forKey: key)
        count = arr.count
        isEmpty = arr.isEmpty
        print("\(key) removed from dictionary with value \(entry) \n")
    }
    
    
    func contains(forKey key: String) -> Bool {
        guard let entry = dict[key] else {
            return false
        }
        return true
    }
    
    
    mutating func forEach (closure: (String, Int) -> (String,Int) ) {
        for (k,v) in dict {
            var closureReturn = closure(k,v)
            var val = closureReturn.1
            dict[k] = val
        }
    }
    
    
    func reduce (_ acc: Int, _ closure: (Int, Int) -> Int) -> Int {
        
        var result: Int = acc
        
        for (k, v) in dict {
            result = closure(result,v)
        }
        
        return result
    }
    
    
    // Might not work
    mutating func remove(closure: (String, Int) -> Bool) -> [[String: Int]] {
        var result: [[String: Int]] = []
        
        for k in arr {
            var v: Int = dict[k]!
            let check: Bool = closure(k, v)
            
            if check == false {
                let removeIndex = arr.firstIndex(of: k)
                guard let removeIndex else { continue }
                arr.remove(at: removeIndex)
                dict.removeValue(forKey: k)
            } else {
                result.append([k:v])
            }
        }
        
        count = arr.count
        isEmpty = arr.isEmpty
        
        return result
    }
    
    
    
    mutating func filter(closure: (String, Int) -> Bool) -> Dict {
        var result = Dict()
        
        for (k, v) in dict {
            let check: Bool = closure(k, v)
            if check == true {
                result[k] = v
            }
        }
        
        return result
    }
    
    
    
    
    mutating func map (closure: (String, Int) -> (String, Int) ) -> Dict {
    
        var result = Dict()
    
        for k in arr {
            var v: Int = dict[k]!
            var closureReturn = closure(k,v)
            var val = closureReturn.1
            result[k] = val
        }
    
        return result
    }
    
    
    mutating func sorted (by closure: (Int, Int) -> Bool ) -> Dict {
        var result = Dict()
        
        guard isEmpty == false else {
            return result
        }
        
        var check: Bool = closure(2,3)
        if check == true {
            var temp = dict.sorted(by: { $0.value < $1.value})
            for i in temp {
                result[i.key] = i.value
            }
        } else {
            var temp = dict.sorted(by: { $0.value > $1.value})
            for i in temp {
                result[i.key] = i.value
            }
        }

        return result
    }
    
    
    
    
}

var dict = Dict()

//print(dict.isEmpty)
//print(dict.count)

dict["a"] = 1
dict["b"] = 2
dict["c"] = 3
dict["d"] = 4
dict["e"] = 5

//print(dict.isEmpty)
//print(dict.count)

//print("*** Ordered Dictionary ***\n")
//
//print(dict.arr,"\n")
//print(dict.dict,"\n")
//
//print(dict["e"],"\n")
//
//dict.printDict()
//
//dict.updateValue(100, forKey: "c")
//dict.printDict()
//
//dict.deleteValue(forKey: "z")
//dict.printDict()
//
//print("Contains 'a': ", dict.contains(forKey: "a"))
//print("Contains 'z': ", dict.contains(forKey: "z"))
//
//print("isEmpty: ", dict.isEmpty())
//print("Count: ", dict.count())



//var dictNew = dict.map { key, val in
//    [key: val+1]
//}
//var dictNew = dict.map { key, val in
//    [key: val-1]
//}
//
//var dictNew = dict.map { key, val in
//    [key: val*1]
//}



// IMP: Read the closure part right below this task before coming to this part.

//  ** forEach **
//dict.forEach { key, val in
//    (key, val+1)
//}
//// This here is the call of function 'map'. map is taking this closure as a paramter and would be calling it during its execution
//
//dict.printDict()



// ** Reduce **
//var dictReduce = dict.reduce(0, { res, val in
//    res + val
//})
//print(dictReduce)



// ** Filter **
//var dictFilter = dict.filter { key, value in
//    value % 2 == 0
//}
//
//print(dictFilter)
//print(dict)


// ** Remove **
//var dictFilter = dict.remove { key, value in
//    value % 2 == 0
//}
//
//print(dictFilter)



// ** Map **

//var dict2 = Dict()
//dict2 = dict.map { key, val in
//    (key, val+1)
//}
//
//dict.printDict()
//dict2.printDict()



// ** Sorted **

//var dict3 = dict.sorted(by: { a,b in
//    a > b
//})

//var dict3 = dict.sorted(by: { a,b in
//    a < b
//})
//
//print(dict3)
//dict3.printDict()












// *** Closures (the tricky part) ***

//var result = closureParent { num in
//    num * num
//}
//func closureParent(closure: (Int) -> Int) -> Int {
//    return closure(5)
//}
//
//print(result)
//
//
//
//var dict5: [Int:Int] = [1:1, 2:2, 3:3]
//var dict6: [Int:Int] = [:]
//
//print(dict5.forEach {key, value in
//    [key: value+1]
//    print(type(of: [key: value+1]))
//})







//mutating func forEach (closure: (String, Int) -> [String:Int] ) -> [[String: Int]] {
//    
//    var result: [[String: Int]] = []
//    
////        Iterated through dictionary here. Works as well but doesn't maintain the order.
//    
////        for (k, v) in dict {
////            var closureReturn: [String: Int] = closure(k,v)
////            result.append(closureReturn)
////            // print(type(of: closureReturn))
////            var val = closureReturn.values.first!
////            dict[k] = val
////        }
//    
//    for k in arr {
//        var v: Int = dict[k]!
//        var closureReturn: [String: Int] = closure(k,v)
//        result.append(closureReturn)
//        // print(type(of: closureReturn))
//        var val = closureReturn.values.first!
//        dict[k] = val
//    }
//    
//    return result
//}







