// *** Closures ***


// ** Different ways of defining a closure **

//let parent = { (a: Int, b: Int) -> Int in
//    return a + b
//}
//let v1 = parent(a: 4, b: 2)
// // This won't work as closure doesn't support labeled parameters. Also this is a global closure

//let v1 = parent(4,2)
//print(v1)



//let parent: (Int,Int) -> Int = { a,b in
//    a + b
//}
//let v1 = parent(4,2)
//print(v1)
// This right here is a closure expression. Notice the subtle difference



//let parent: (Int,Int) -> Int = {
//    $0 + $1
//}
//let v1 = parent(4,2)
//print(v1)




// ** Example: sorted(by:) [Closure expression] **

//let nums = [1,2,3,4,5]

//print(nums.sorted(by: { (x: Int, y: Int) -> Bool in
//    return x > y
//}))
//
//print(nums.sorted(by: { x,y in
//    x > y
//}))
//
//print(nums.sorted(by: { $0 > $1 }))
//
//print(nums.sorted(by: >))



// ** Capturing values **

//var f1: () -> String = {
//    var temp = 5
//    return "Hello \(temp)"
//}
//
//print(f1())
//print(type(of: f1))
//
//// Closures are reference types


// * Nested functions *

//func f1 (_ n1: Int) -> () -> Int {
//    var temp = 0
//    func f2 () -> Int{
//        temp += n1
//        return temp
//    }
//    return f2
//}
//
//var f3 = f1(5)
//print(f3())
//print(f3())
//print(f3())

// Reference of n1 and temp is stored




// *** Optionals ***


// Methods or operations cannot be applied on something that is optional, because just in case if it is nil, an error will be thrown

//func abc (arr: [Int]?) {
//    guard let arrTemp = arr else {
//        print("Array in nil")
//        return
//    }
//    print(arrTemp.count)
//}
////var a1: [Int]? = nil
//var a1: [Int]? = [1,2,3,4,5]
//abc(arr: a1)


//func f1 (n1: Int?, n2: Int) {
//    print(n1! + n2)
//}


//var v2: Int? = nil
//if v2 == nil {
//    print("var is nil")
//}


// *** Recursive Enum ***

//indirect enum Rect {
//    case side(Int)
//    case area(Rect, Rect)
//}
//
//func rectangle (_ rect: Rect) -> Int {
//    switch rect {
//    case let .side(value):
//        return value
//    case let .area (l, r):
//        return rectangle(l) * rectangle(r)
//    }
//}
//    
//    
//    let length = Rect.side(5)
//    let breadth = Rect.side(5)
//    let areaVar = Rect.area(length,breadth)
//    let area = rectangle(areaVar)
//
//    print(area)


// *** Types of properties in Struct / Class ***


// ** Lazy **

//struct Lazy {
//    lazy var data: Int = fetchData()
//    func fetchData() -> Int {
//        var temp = 0
//        for i in 1...1000{
//            temp += i
//        }
//        return temp
//    }
//    
//    // A function defined within a class can be called only when an instance of it has been initialzed.
//    
////    lazy var data: Int = {
////        return (1...500).reduce(0, { $0 + $1 })
////    }()
//}
//
//var inst1 = Lazy()
//print(inst1.data)


// ** Computed **

struct rect {
    var l: Int
    var b: Int
    
    var area: Int {
        return l * b
    }
}

var inst1 = rect(l:5, b:10)
print(inst1.area)
print(inst1.l)


























